
import { BrowserRouter,Routes,Route} from "react-router-dom"
import About from "./Component/About"
import Explore from "./Component/Explore"
import Home from "./Component/Home"
import Navbar from "./Component/Navbar"
import Contact from "./Component/Contact"

function App(){
  return(
    <>
      <BrowserRouter>
      <Navbar />
        <Routes>
            <Route path='/' element={<Home />}></Route>
            <Route path='/about' element={<About />}></Route>
            <Route path='/explore' element={<Explore />}></Route>
            <Route path='/contact' element={<Contact />}></Route>           
        </Routes>
      </BrowserRouter>
    </>
  )   
}
export default App
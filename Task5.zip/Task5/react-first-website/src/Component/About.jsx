import React from 'react'
import './about.css';
const About = () => {
  return (

    <div>
      
      <section className="about-section">
        <div className="container">
          <h1>About Us</h1>
          <p>
            Welcome to <strong>Foodie Haven</strong>, where passion meets flavor.
            We are a team of chefs, food enthusiasts, and creators dedicated to serving fresh, delicious, and nutritious meals to our community.
            Our mission is to bring people together through the love of good food.
          </p>

          {/* Team Section */}
          <div className="team">
            <h2>Our Team</h2>
            <p>Meet the passionate people who make it all possible.</p>

            <div className="team-members">
              <div className="member">
                <img src="https://images.squarespace-cdn.com/content/v1/6348398d9d21fd6277c64f96/1690311572717-5BBW03AE2BTLF2I4OI45/hackman+team+factors+article.png" alt="Chef John" style={{width:'500px'}}/>
                <h3>Meet Our Amazing Team:</h3>
                <p>Our team is the heart of Foodie Haven. These are the faces behind every plate, the creators who bring unique flavors and inspiring dishes to life.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

     {/* Featured Dishes */}
  <footer class="footer">
  <div class="container">
    <p>&copy; 2025 Foodie Haven. All rights reserved.</p>
    <p class="footer-note">Made with love for food lovers everywhere.</p>
    <p>Made with 💗 <a href='https://www.linkedin.com/in/sakshi-yemul-7aa290344?'>Sakshi Yemul</a></p>
  </div>
  </footer>
    </div>
  )
}

export default About
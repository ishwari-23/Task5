import React from 'react'
import './home.css'
const Home = () => {
  return (
    <div>
      <div>
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <h1>Welcome to Foodie Haven!</h1>
          <p>Explore the world of flavors and find your next favorite dish.</p>
          <button className="cta-btn">Explore Now</button>
        </div>
      </section>

      {/* Food Categories */}
      <section className="categories-section">
        <div className="container">
          <h2>Food Categories</h2>
          <div className="categories-grid">
            <div className="category">
              <img src="https://content.jdmagicbox.com/comp/pune/b7/020pxx20.xx20.211102034922.p8b7/catalogue/ovenstory-pizza-chinchwad-east-pune-pizza-outlets-igzoufnqqc.jpg" alt="Pizza" />
              <h3>Pizza</h3>
              <p>Deliciously cheesy pizzas with a variety of toppings.</p>
            </div>
            <div className="category">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUW-iTjaM4sxsXUIPETC_VdBd7sgtiJyIf7Q&s" alt="Sushi" />
              <h3>Burger</h3>
              <p>Juicy Burgers, Fresh Ingredients, Unbeatable Flavor</p>
            </div>
            <div className="category">
              <img src="https://i.ytimg.com/vi/iQ38VKAjQgo/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBYeSca3xOzPVWec6G-I6XqaZ8z4Q" alt="Burger" />
              <h3>Pasta</h3>
              <p>Juicy, mouth-watering Pasta made with the finest ingredients.</p>
            </div>
            <div className="category">
              <img src="https://kwokspots.com/wp-content/uploads/2022/02/chow-mein-far-500x375.png" alt="Pasta" />
              <h3>Chinese</h3>
              <p>Fresh Chinese with rich, flavorful sauces.</p>
            </div>
            <div className="category">
              <img src="https://www.livofy.com/health/wp-content/uploads/2021/09/Club-Sandwich-with-Super-Mayo.jpg" alt="Pasta" />
              <h3>Sandwich</h3>
              <p>Satisfy Your Hunger with Every Bite</p>
            </div>
            <div className="category">
              <img src="https://www.inspiredtaste.net/wp-content/uploads/2022/10/Baked-French-Fries-Recipe-1200.jpg" alt="Pasta" />
              <h3>French Fries</h3>
              <p>Crispy, golden fries with perfect seasoning.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="featured-dishes-section">
        <div className="container">
          <h2>Featured Dishes</h2>
          <div className="featured-dishes-grid">
            <div className="dish">
              <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRiD5N8diFg3U2FCE7nuONhB6su0gzJYuW-jg&s" alt="Margherita Pizza" />
              <h3>Margherita Pizza</h3>
              <p>Classic pizza with fresh mozzarella and basil.</p>
            </div>
            <div className="dish">
              <img src="https://www.otafukusauce.com/e/recipes/images/114sushiroll.jpg" alt="Sushi Roll" />
              <h3>Sushi Roll</h3>
              <p>Freshly made sushi with premium ingredients.</p>
            </div>
            <div className="dish">
              <img src="https://i.ytimg.com/vi/SvOx7tA_Cv8/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLAUi4DTtB9e2mnIAe3JoxUoj6nbNA" alt="Cheeseburger" />
              <h3>Cheeseburger</h3>
              <p>Grilled beef patty with melted cheese and fresh toppings.</p>
            </div>
          </div>
        </div>
      </section>

  {/* Featured Dishes */}
  <footer class="footer">
  <div class="container">
    <p>&copy; 2025 Foodie Haven. All rights reserved.</p>
    <p class="footer-note">Made with love for food lovers everywhere.</p>
    <p>Made with 💗 <a href='https://www.linkedin.com/in/sakshi-yemul-7aa290344?'>Sakshi Yemul</a></p>
  </div>
  </footer>

    </div>
    </div>
  )
}

export default Home